/**
 * Red Rocket Digital Theme JavaScript
 * Version 2.2.0
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        
        // Mobile Menu Toggle
        var $mobileToggle = $('.mobile-menu-toggle');
        var $mainNav = $('.main-nav');
        var $navMenu = $('.nav-menu');
        
        $mobileToggle.on('click', function() {
            $(this).toggleClass('active');
            $navMenu.toggleClass('mobile-open');
            
            // Toggle icon
            var $icon = $(this).find('i');
            if ($icon.hasClass('fa-bars')) {
                $icon.removeClass('fa-bars').addClass('fa-times');
            } else {
                $icon.removeClass('fa-times').addClass('fa-bars');
            }
        });
        
        // Close mobile menu on link click
        $navMenu.find('a').on('click', function() {
            if ($navMenu.hasClass('mobile-open')) {
                $navMenu.removeClass('mobile-open');
                $mobileToggle.removeClass('active');
                $mobileToggle.find('i').removeClass('fa-times').addClass('fa-bars');
            }
        });
        
        // Dropdown toggle for mobile
        $('.menu-item-has-children > a').on('click', function(e) {
            if ($(window).width() <= 1024) {
                e.preventDefault();
                $(this).parent().toggleClass('submenu-open');
                $(this).siblings('.sub-menu').slideToggle(300);
            }
        });
        
        // Smooth scroll for anchor links
        $('a[href^="#"]').on('click', function(e) {
            var target = $(this.getAttribute('href'));
            if (target.length && this.getAttribute('href') !== '#') {
                e.preventDefault();
                $('html, body').animate({
                    scrollTop: target.offset().top - 80
                }, 800);
            }
        });
        
        // Header scroll effect
        var $header = $('.site-header');
        var lastScrollTop = 0;
        
        $(window).on('scroll', function() {
            var scrollTop = $(this).scrollTop();
            
            // Add scrolled class
            if (scrollTop > 100) {
                $header.addClass('scrolled');
            } else {
                $header.removeClass('scrolled');
            }
            
            // Hide/show header on scroll (optional)
            // if (scrollTop > lastScrollTop && scrollTop > 200) {
            //     $header.addClass('header-hidden');
            // } else {
            //     $header.removeClass('header-hidden');
            // }
            
            lastScrollTop = scrollTop;
        });
        
        // Animate elements on scroll
        function animateOnScroll() {
            $('.rr-service-card, .rr-testimonial, .rr-process-step, .rr-stat').each(function() {
                var elementTop = $(this).offset().top;
                var viewportBottom = $(window).scrollTop() + $(window).height();
                
                if (elementTop < viewportBottom - 50) {
                    $(this).addClass('animated');
                }
            });
        }
        
        $(window).on('scroll', animateOnScroll);
        animateOnScroll(); // Run on load
        
        // Form validation enhancement
        $('form').on('submit', function(e) {
            var $form = $(this);
            var valid = true;
            
            $form.find('[required]').each(function() {
                if (!$(this).val().trim()) {
                    valid = false;
                    $(this).addClass('error');
                } else {
                    $(this).removeClass('error');
                }
            });
            
            // Email validation
            $form.find('input[type="email"]').each(function() {
                var email = $(this).val();
                var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (email && !emailRegex.test(email)) {
                    valid = false;
                    $(this).addClass('error');
                }
            });
            
            if (!valid) {
                e.preventDefault();
            }
        });
        
        // Remove error class on input
        $('input, textarea, select').on('focus', function() {
            $(this).removeClass('error');
        });
        
    });
    
})(jQuery);
